/*
 * ============================================================
 *  PORTAL SETTINGS - edit this file only (no build needed)
 * ============================================================
 *  After editing, upload this file to the router's hotspot folder.
 *  Keep the quotes " " and commas , exactly as shown, or the page will break.
 */
var data = {

    /* Name shown on every page and in the browser tab. */
    "portal_name": "PisoWiFi",

    /* Base link of your WaspRadius server.
     * No slash at the end. Example: "https://billing.example.com" */
    "host": "https://v2.waspradi.us",

    /* Your PUBLIC API key from WaspRadius:
     *   Account Settings > API Keys > Public key  (starts with "wpk_")
     *
     * Only the PUBLIC key goes here - it is visible to anyone who opens the
     * hotspot page, and that is expected. Never put the secret key ("wsk_") here.
     * Empty "" = the Extend button and the live price list are turned off. */
    "api_key": "wpk_cd1f00e648bc5b73812664f8cba0cbc5",

    /* WaspRadius API endpoints. You normally do not need to change these.
     *
     * Each value can be:
     *   - a path  -> joined to "host" above
     *   - a full link (starts with http:// or https://) -> used as is
     *   - ""  (empty) -> turns the feature off
     *
     * profiles: price list on the login page, read live from your
     *           Voucher Profiles. If it cannot be loaded, "rates" below is shown.
     * extend:   "Extend time" button on the status page. Adds a new, unused
     *           voucher's time/data/validity to the voucher that is logged in.
     * info:     "Valid until" row on the status page.
     */
    "api": {
        "profiles": "/api/ext/hotspot/profiles",
        "extend": "/api/ext/voucher/extend",
        "info": "/api/ext/voucher/info"
    },

    /* Currency label for the live price list, used ONLY if WaspRadius does not
     * send one. Normally the symbol set in WaspRadius (Account Settings >
     * Company Details > Currency Symbol) is used, so you do not need to change this. */
    "currency": "₱",

    /* BACKUP price list - shown only when the live list above is off or cannot
     * be loaded (for example the server is not in the walled garden yet).
     * rate_name = currency label, rate = price, time = what the price buys. */
    "rates": [
        { "rate_name": "Php", "rate": "5", "time": "4 Hours" },
        { "rate_name": "Php", "rate": "10", "time": "12 Hours" }
    ],

    /* Coin machine (WaspCoin ESP) on this hotspot's network.
     * Its IP address, as shown when you set it up, e.g. "192.168.88.57".
     * Set = "Insert Coin" on the login page and "Add time" on the status page.
     * Empty "" = no coin buttons.
     * In MikroTik, add the IP to the walled garden (see README). */
    "coinslot_ip": "192.168.88.86",

    /* Slide images on the login page. Files must be inside the "img" folder.
     * Best size 1200x630, keep each under ~80 KB (run `npm run images`).
     * One image = no sliding. Empty list [] = slide box hidden. */
    "slides": [
        "slide1.jpg"
    ]
};
