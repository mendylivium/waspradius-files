/* ---- src/shared/portal-core.js ---- */
/*
 * WaspRadius portal core - shared by every build (MikroTik, Omada, standalone EAP).
 * scripts/build.mjs puts this file first in js/portal.js, then the target's own code.
 *
 * Plain ES5 on purpose (old phones), no jQuery.
 * Never write "$" followed by "(" here: the MikroTik build copies this file to the
 * router, which treats it as a template variable. build-mikrotik refuses to build
 * when it finds one.
 */
(function (window, document) {
  'use strict';

  var cfg =
    (typeof data !== 'undefined' && data) ||
    (typeof portalCfg !== 'undefined' && portalCfg) ||
    {};

  var API_DEFAULTS = {
    profiles: '/api/ext/hotspot/profiles',
    extend: '/api/ext/voucher/extend',
    info: '/api/ext/voucher/info',
  };

  /*
   * Full URL of a WaspRadius API endpoint from config.js ("api" section).
   * - full link ("https://...")   -> used as is
   * - path ("/api/...")           -> joined to "host"
   * - "" (empty)                  -> feature turned off, returns ""
   * - not set                     -> default path above, joined to "host"
   *
   * Every /api/ext endpoint authenticates the tenant by the public API key, so
   * without "api_key" the call can only ever answer 401. Treat that as "feature
   * off" here instead of showing customers a button that always fails.
   */
  function apiUrl(name) {
    var api = cfg.api || {};
    var path = api.hasOwnProperty(name) ? api[name] : API_DEFAULTS[name];
    if (!path || !cfg.api_key) return '';
    if (/^https?:\/\//i.test(path)) return path;
    if (!cfg.host) return '';
    return String(cfg.host).replace(/\/+$/, '') + '/' + String(path).replace(/^\/+/, '');
  }

  function warn(text) {
    if (window.console && console.warn) console.warn('[portal] ' + text);
  }

  function byId(id) {
    return document.getElementById(id);
  }

  function setText(id, text) {
    var el = byId(id);
    if (el) el.textContent = text;
  }

  function show(el, visible) {
    if (typeof el === 'string') el = byId(el);
    if (!el) return;
    if (visible === false) el.classList.add('hidden');
    else el.classList.remove('hidden');
  }

  function getCookie(name) {
    var m = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
    return m ? decodeURIComponent(m[2]) : '';
  }

  function setCookie(name, value, days) {
    var d = new Date();
    d.setTime(d.getTime() + days * 864e5);
    document.cookie =
      name + '=' + encodeURIComponent(value) + ';expires=' + d.toUTCString() + ';path=/';
  }

  function request(method, url, body, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, url, true);
    xhr.timeout = 15000;
    if (body) xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      var json = null;
      try {
        json = JSON.parse(xhr.responseText);
      } catch (e) {}
      cb(xhr.status >= 200 && xhr.status < 300, json, xhr);
    };
    xhr.send(body || null);
  }

  /*
   * Call the WaspRadius API. The server answers with the envelope
   * { success, message, data, error }; cb gets (ok, data, errorText, xhr).
   *
   * The key travels in the X-Api-Key header (the server reads it only there).
   * A custom header makes the browser send a CORS preflight first, so the
   * server must list X-Api-Key in its allowed headers - when it does not, the
   * browser blocks the call and it arrives here as status 0, exactly like a
   * network failure. The console line is what tells those two apart.
   */
  function apiRequest(method, url, payload, timeout, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, url, true);
    xhr.timeout = timeout;
    xhr.setRequestHeader('Accept', 'application/json');
    xhr.setRequestHeader('X-Api-Key', cfg.api_key);
    if (payload) xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      var json = null;
      try {
        json = JSON.parse(xhr.responseText);
      } catch (e) {}
      var ok = xhr.status >= 200 && xhr.status < 300 && !!json && json.success !== false;
      if (xhr.status === 0) {
        warn(method + ' ' + url + ' failed: server unreachable, not in the walled garden, or blocked by CORS');
      }
      cb(ok, json && json.data, (json && (json.error || json.message)) || '', xhr);
    };
    xhr.send(payload ? JSON.stringify(payload) : null);
  }

  function formatBytes(bytes) {
    bytes = parseInt(bytes, 10);
    if (isNaN(bytes)) return '';
    if (bytes <= 0) return '0 B';
    var units = ['B', 'KB', 'MB', 'GB', 'TB'];
    var i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + units[i];
  }

  function pad(n) {
    return n < 10 ? '0' + n : '' + n;
  }

  function formatDuration(secs) {
    secs = Math.max(0, Math.floor(secs));
    var d = Math.floor(secs / 86400);
    var h = Math.floor((secs % 86400) / 3600);
    var m = Math.floor((secs % 3600) / 60);
    var s = secs % 60;
    return (d ? d + 'd ' : '') + pad(h) + ':' + pad(m) + ':' + pad(s);
  }

  /* MikroTik time string ("1w2d3h4m5s") -> seconds. Fallback when *-secs vars are missing. */
  function parseRosTime(str) {
    if (!str) return NaN;
    var units = { w: 604800, d: 86400, h: 3600, m: 60, s: 1 };
    var total = 0;
    var found = false;
    String(str).replace(/(\d+)([wdhms])/g, function (_, n, u) {
      total += parseInt(n, 10) * units[u];
      found = true;
    });
    if (found) return total;
    var hms = String(str).split(':'); // "hh:mm:ss"
    if (hms.length === 3) return +hms[0] * 3600 + +hms[1] * 60 + +hms[2];
    return NaN;
  }

  function toSeconds(secs, text) {
    var n = parseInt(secs, 10);
    return isNaN(n) ? parseRosTime(text) : n;
  }

  function applyPortalName() {
    var name = cfg.portal_name || 'WiFi';
    var nodes = document.querySelectorAll('[data-portal-name]');
    for (var i = 0; i < nodes.length; i++) nodes[i].textContent = name;
    var suffix = document.body.getAttribute('data-title');
    document.title = name + (suffix ? ' | ' + suffix : '');
  }

  /* ---------------- price list + slides (login pages) ---------------- */

  /* Price text: 5 -> "5", 12.5 -> "12.50". */
  function formatPrice(value) {
    var n = parseFloat(value);
    if (isNaN(n)) return String(value == null ? '' : value);
    return n % 1 === 0 ? String(n) : n.toFixed(2);
  }

  /* Seconds -> "4 Hours", "1 Day 12 Hours", "30 Minutes". "" for 0 / none. */
  function humanDuration(secs) {
    secs = parseInt(secs, 10);
    if (isNaN(secs) || secs <= 0) return '';
    var units = [[86400, 'Day'], [3600, 'Hour'], [60, 'Minute'], [1, 'Second']];
    var parts = [];
    for (var i = 0; i < units.length && parts.length < 2; i++) {
      var n = Math.floor(secs / units[i][0]);
      if (n > 0) {
        parts.push(n + ' ' + units[i][1] + (n > 1 ? 's' : ''));
        secs -= n * units[i][0];
      } else if (parts.length) {
        break; // "1 Day 5 Minutes" reads worse than "1 Day"
      }
    }
    return parts.join(' ');
  }

  /*
   * One row per Voucher Profile: price | name, with time / data / validity under
   * it. Time/data/validity of 0 mean "no limit" on the server
   * (models.VoucherRemainingSeconds), so they are left out rather than shown
   * as "0". Profile names are written by the tenant - always escaped.
   */
  /*
   * currency: the tenant's symbol from WaspRadius (Account Settings), so the
   * portal matches the tenant's panel and invoices without editing config.js.
   * config.js "currency" is only used when the server did not send one.
   */
  function profileRows(profiles, currency) {
    currency = currency || cfg.currency || '';
    var rows = [];
    for (var i = 0; i < profiles.length; i++) {
      var p = profiles[i];
      var details = [];
      var time = humanDuration(p.time_credit);
      if (time && time.toLowerCase() !== String(p.name).toLowerCase()) details.push(time);
      if (p.data_credit > 0) details.push(formatBytes(p.data_credit));
      if (p.validity > 0) details.push('valid ' + humanDuration(p.validity));
      rows.push({
        price: parseFloat(p.price) > 0 ? (currency + ' ' + formatPrice(p.price)) : 'Free',
        sort: parseFloat(p.price) || 0,
        title: p.name,
        detail: details.join(' · '),
      });
    }
    return rows;
  }

  function configRows() {
    var rates = cfg.rates || [];
    var rows = [];
    for (var i = 0; i < rates.length; i++) {
      rows.push({
        price: (rates[i].rate_name || '') + ' ' + rates[i].rate,
        sort: parseFloat(rates[i].rate) || 0,
        title: rates[i].time,
        detail: '',
      });
    }
    return rows;
  }

  function drawRates(rows) {
    var body = byId('rates-body');
    if (!body || !rows.length) {
      show('rates-card', false);
      return;
    }
    rows.sort(function (a, b) {
      return a.sort - b.sort;
    });
    var html = '';
    for (var i = 0; i < rows.length; i++) {
      html +=
        '<tr><td class="font-semibold">' +
        escapeHtml(rows[i].price) +
        '</td><td class="text-right">' +
        escapeHtml(rows[i].title) +
        (rows[i].detail ? '<div class="text-xs opacity-60">' + escapeHtml(rows[i].detail) + '</div>' : '') +
        '</td></tr>';
    }
    body.innerHTML = html;
    show('rates-card');
  }

  /*
   * The login page is shown BEFORE the customer is logged in, so the router only
   * lets this request out if the WaspRadius host is in the hotspot walled garden.
   * When it is not (or the API is off / down), the backup "rates" from config.js
   * are shown instead of an empty box. Short timeout: a customer is waiting.
   */
  // The tenant's symbol from the last price list WaspRadius sent, so other
  // widgets (the coin machine) match it; config.js "currency" before that.
  var lastCurrency = '';

  function currencySymbol() {
    return lastCurrency || cfg.currency || '';
  }

  function renderRates() {
    var url = apiUrl('profiles');
    if (!url) {
      drawRates(configRows());
      return;
    }
    apiRequest('GET', url, null, 6000, function (ok, data, error) {
      var profiles = ok && data && data.profiles;
      if (profiles && profiles.length) {
        if (data.currency) lastCurrency = data.currency;
        drawRates(profileRows(profiles, data.currency));
        return;
      }
      if (!ok && error) warn('price list: ' + error);
      drawRates(configRows());
    });
  }

  function renderSlides() {
    var frame = byId('slides');
    var dotsEl = byId('slide-dots');
    var slides = cfg.slides || [];
    if (!frame || !slides.length) {
      show('slides-card', false);
      return;
    }
    var imgs = [];
    var dots = [];
    for (var i = 0; i < slides.length; i++) {
      var img = document.createElement('img');
      img.className = 'slide' + (i === 0 ? ' is-active' : '');
      img.src = 'img/' + slides[i];
      img.alt = '';
      frame.appendChild(img);
      imgs.push(img);

      if (slides.length > 1) {
        var dot = document.createElement('button');
        dot.type = 'button';
        dot.className = 'w-2 h-2 rounded-full bg-base-300' + (i === 0 ? ' !bg-primary' : '');
        dot.setAttribute('aria-label', 'Slide ' + (i + 1));
        dot.onclick = (function (n) {
          return function () {
            go(n);
            restart();
          };
        })(i);
        dotsEl.appendChild(dot);
        dots.push(dot);
      }
    }
    if (slides.length < 2) {
      show(dotsEl, false);
      return;
    }

    var current = 0;
    var timer = null;
    function go(n) {
      imgs[current].classList.remove('is-active');
      dots[current].classList.remove('!bg-primary');
      current = (n + imgs.length) % imgs.length;
      imgs[current].classList.add('is-active');
      dots[current].classList.add('!bg-primary');
    }
    function restart() {
      clearInterval(timer);
      timer = setInterval(function () {
        go(current + 1);
      }, 5000);
    }
    restart();
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ---------------- voucher login form (every login page) ---------------- */

  /*
   * Remember the voucher the customer logs in with. MikroTik only uses it to
   * pre-fill the login page; on Omada / EAP it is the ONLY way the status page
   * knows which voucher to show, because those devices give the page no
   * template variables. Cookie + localStorage: iOS's captive-portal window may
   * drop one of them.
   */
  function rememberVoucher(code) {
    setCookie('vouch', code, 1);
    try {
      window.localStorage.setItem('wasp_voucher', code);
    } catch (e) {}
  }

  function recallVoucher() {
    var code = getCookie('vouch');
    if (code) return code;
    try {
      return window.localStorage.getItem('wasp_voucher') || '';
    } catch (e) {
      return '';
    }
  }

  function trim(s) {
    return String(s == null ? '' : s).replace(/^\s+|\s+$/g, '');
  }

  function initVoucherForm(form) {
    var saved = recallVoucher();
    if (saved && !form.username.value) form.username.value = saved;

    // "Voucher has a password" switch: off = voucher only (password = voucher code).
    var hasPass = byId('has-pass');
    if (hasPass) {
      hasPass.checked = getCookie('haspass') === '1';
      show('pass-wrap', hasPass.checked);
      hasPass.onchange = function () {
        show('pass-wrap', hasPass.checked);
        setCookie('haspass', hasPass.checked ? '1' : '0', 30);
        if (hasPass.checked) form.password.focus();
      };
    }

    var showPass = byId('show-pass');
    if (showPass) {
      showPass.onclick = function () {
        var hidden = form.password.type === 'password';
        form.password.type = hidden ? 'text' : 'password';
        showPass.textContent = hidden ? 'Hide' : 'Show';
      };
    }

    if (!form.username.value) form.username.focus();
  }

  /*
   * { user, pass } ready to send, or null after focusing the field that is
   * missing. Voucher only: the password is the voucher code itself - the RADIUS
   * server skips the check for a voucher that has no password stored.
   */
  function readVoucherForm(form) {
    var user = trim(form.username.value);
    if (!user) {
      form.username.focus();
      return null;
    }
    var hasPass = byId('has-pass');
    var withPassword = hasPass && hasPass.checked;
    if (withPassword && !form.password.value) {
      form.password.focus();
      return null;
    }
    rememberVoucher(user);
    return { user: user, pass: withPassword ? form.password.value : user };
  }

  function setBusy(id, text) {
    // Not named btn: Tailwind scans this file, and an exclamation mark right
    // before that name reads as an important .btn variant (~7 KB more CSS on the router).
    var button = byId(id);
    if (!button) return;
    button.disabled = true;
    button.innerHTML = '<span class="loading loading-spinner loading-sm"></span> ' + escapeHtml(text || 'Connecting');
  }

  /*
   * Go's time JSON ("2026-09-14T10:00:00.123456789+08:00") -> Date. Parsed by
   * hand: old Android WebViews return Invalid Date for more than 3 fractional
   * digits, which is what Go sends.
   */
  function parseServerTime(value) {
    var m = String(value || '').match(
      /^(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)(?:\.\d+)?(Z|([+-])(\d\d):(\d\d))$/
    );
    if (!m) return null;
    var utc = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
    if (m[7] !== 'Z') {
      var offset = (+m[9] * 60 + +m[10]) * 60000;
      utc += m[8] === '+' ? -offset : offset;
    }
    return new Date(utc);
  }

  /* "Sep 14, 2026 10:00 AM" in the time zone of the customer's device. */
  function formatDateTime(date) {
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var h = date.getHours();
    var ampm = h < 12 ? 'AM' : 'PM';
    h = h % 12 || 12;
    return (
      months[date.getMonth()] + ' ' + date.getDate() + ', ' + date.getFullYear() + ' ' +
      h + ':' + pad(date.getMinutes()) + ' ' + ampm
    );
  }

  /*
   * Server error text -> what the customer should do. Keyed by the exact
   * messages of ExtendVoucherPublic (server/internal/controllers/
   * voucher_extend_controller.go); an unknown message is shown as is.
   * `field` names the input to reveal/focus so the customer can fix it.
   */
  var EXTEND_ERRORS = {
    'new_voucher not found': { text: 'Voucher code not found.' },
    'new_voucher has already been used': { text: 'This voucher has already been used.' },
    'new_voucher password is incorrect': { text: 'Enter the correct password of the new voucher.', field: 'new' },
    'current_voucher password is incorrect': { text: 'Enter the password of the voucher you are using now.', field: 'current' },
    'current_voucher and new_voucher must be different': { text: 'Enter a different voucher code.' },
    'current_voucher has already expired': { text: 'Your voucher has expired. Log out and log in with the new voucher instead.' },
    'current_voucher not found': { text: 'This session cannot be extended. Log out and log in with the new voucher instead.' },
    'current_voucher is not active yet': { text: 'This session cannot be extended yet. Please try again.' },
  };

  function setupExtend(info, onSuccess) {
    var modal = byId('extend-modal');
    var form = document.forms.extend;
    if (!modal || !form) return;

    // Extend tops up the VOUCHER that is logged in. A MAC or trial login has
    // no voucher code as its username, so the server can only answer
    // "current_voucher not found" - hide the button instead.
    var extendUrl = apiUrl('extend');
    if (!extendUrl || info.loginBy === 'mac' || info.loginBy === 'trial' || !info.username) {
      show('extend-open', false);
      return;
    }

    var msg = byId('extend-msg');
    var btn = byId('extend-submit');
    var newHasPass = byId('extend-has-pass');
    var usedPassword = getCookie('haspass') === '1'; // how the customer logged in

    function setMsg(type, text) {
      if (!text) {
        show(msg, false);
        return;
      }
      msg.className = 'alert text-sm mt-3 ' + (type === 'ok' ? 'alert-success' : 'alert-error');
      msg.textContent = text;
    }
    function showNewPass(on) {
      newHasPass.checked = on;
      show('extend-pass-wrap', on);
    }
    function open() {
      setMsg();
      form.voucher.value = '';
      form.voucher_password.value = '';
      showNewPass(false);
      show('current-pass-wrap', usedPassword);
      modal.classList.add('modal-open');
      setTimeout(function () {
        form.voucher.focus();
      }, 50);
    }
    function close() {
      modal.classList.remove('modal-open');
    }

    byId('extend-open').onclick = open;
    byId('extend-cancel').onclick = close;
    modal.onclick = function (e) {
      if (e.target === modal) close();
    };
    newHasPass.onchange = function () {
      showNewPass(newHasPass.checked);
      if (newHasPass.checked) form.voucher_password.focus();
    };

    form.onsubmit = function () {
      var voucher = trim(form.voucher.value);
      if (!voucher) {
        form.voucher.focus();
        return false;
      }
      if (newHasPass.checked && !form.voucher_password.value) {
        form.voucher_password.focus();
        return false;
      }
      var currentWrap = byId('current-pass-wrap');
      var askCurrent = currentWrap && currentWrap.className.indexOf('hidden') < 0;
      if (askCurrent && !form.current_password.value) {
        form.current_password.focus();
        return false;
      }

      // Same rule as the login page: "no password" means the password is the
      // voucher code itself. The server skips the check for a voucher that has
      // no password stored, so this is only ever compared when one exists.
      var payload = {
        current_voucher: info.username,
        current_voucher_password: askCurrent ? form.current_password.value : info.username,
        new_voucher: voucher,
        new_voucher_password: newHasPass.checked ? form.voucher_password.value : voucher,
      };

      btn.disabled = true;
      setMsg();
      apiRequest('POST', extendUrl, payload, 15000, function (ok, data, error, xhr) {
        btn.disabled = false;
        if (ok && data) {
          onExtended(data);
          return;
        }
        if (xhr.status === 0) {
          setMsg('err', 'Cannot reach the server. Please try again.');
          return;
        }
        // 401/403 = the portal's API key, or the operator's own account, is not
        // valid right now. That is not something the customer can fix, and the
        // exact reason (e.g. "No active subscription") is the operator's
        // business - show it in the console only.
        if (xhr.status === 401 || xhr.status === 403) {
          warn('extend refused (' + xhr.status + '): ' + error);
          setMsg('err', 'Extend is not available right now. Please contact the WiFi owner.');
          return;
        }
        var known = EXTEND_ERRORS[error];
        if (known && known.field === 'new') {
          showNewPass(true);
          form.voucher_password.focus();
        } else if (known && known.field === 'current') {
          show('current-pass-wrap');
          form.current_password.value = '';
          form.current_password.focus();
        }
        setMsg('err', known ? known.text : error || 'Could not extend. Please try again.');
      });
      return false;
    };

    function onExtended(data) {
      var added = data.extended_by || {};
      var parts = [];
      if (added.time_credit > 0) parts.push(humanDuration(added.time_credit));
      if (added.data_credit > 0) parts.push(formatBytes(added.data_credit));
      var text = 'Success! ' + (parts.length ? parts.join(' + ') + ' added.' : 'Your voucher has been extended.');

      // live_update "failed": the credit is saved, but the router did not get the
      // new Session-Timeout, so this session may still end at the old time. The
      // time is not lost - logging in again with the same voucher picks it up.
      if (data.live_update === 'failed') {
        text += ' If your time does not update, log out and log in again with the same voucher.';
      }
      setMsg('ok', text);

      showValidUntil(data.expiration);

      form.voucher.value = '';
      form.voucher_password.value = '';
      if (form.current_password) form.current_password.value = '';
      setTimeout(onSuccess, 1500);
      setTimeout(close, 4000);
    }
  }

  /* ---------------- voucher info (status pages) ---------------- */

  /* POST /api/ext/voucher/info. cb(ok, data, error, xhr); never called when off. */
  function fetchVoucherInfo(code, cb) {
    var url = apiUrl('info');
    if (!url || !code) return false;
    apiRequest('POST', url, { voucher: code }, 10000, cb);
    return true;
  }

  function showValidUntil(expiration) {
    var expires = parseServerTime(expiration);
    if (!expires) return;
    setText('valid-until', formatDateTime(expires));
    show('valid-until-row');
  }

  window.PortalCore = {
    cfg: cfg,
    apiUrl: apiUrl,
    apiRequest: apiRequest,
    request: request,
    warn: warn,
    byId: byId,
    setText: setText,
    show: show,
    getCookie: getCookie,
    setCookie: setCookie,
    trim: trim,
    escapeHtml: escapeHtml,
    formatBytes: formatBytes,
    formatDuration: formatDuration,
    formatPrice: formatPrice,
    currencySymbol: currencySymbol,
    humanDuration: humanDuration,
    toSeconds: toSeconds,
    parseServerTime: parseServerTime,
    formatDateTime: formatDateTime,
    applyPortalName: applyPortalName,
    renderRates: renderRates,
    renderSlides: renderSlides,
    rememberVoucher: rememberVoucher,
    recallVoucher: recallVoucher,
    initVoucherForm: initVoucherForm,
    readVoucherForm: readVoucherForm,
    setBusy: setBusy,
    fetchVoucherInfo: fetchVoucherInfo,
    showValidUntil: showValidUntil,
    setupExtend: setupExtend,
  };
})(window, document);

/* ---- targets/mikrotik/js/coinslot.js ---- */
/*
 * Coin machine (WaspCoin ESP firmware, coinslot_firmware/) on the hotspot LAN.
 *
 * Shown only when config.js "coinslot_ip" is set. The page talks to the ESP
 * directly; the ESP holds the WaspRadius device key and asks the server for the
 * voucher, so the customer's browser never sees the key - only a session token.
 *
 * Requests are "simple" CORS requests (GET, or POST form-urlencoded, no custom
 * headers): the browser sends them without a preflight, which keeps the ESP's
 * web server simple. The login page must reach the ESP before login, so its IP
 * has to be in the MikroTik walled garden.
 *
 * Plain ES5 (old phones). Never write "$" followed by "(" here (MikroTik).
 */
(function (window, document) {
  'use strict';

  var C = window.PortalCore;
  var POLL_MS = 1000;
  // Idle pages ask rarely; a page whose customer is queueing asks often, so the
  // button arms within a couple of seconds of the machine freeing itself.
  var PING_READY_MS = 10000;
  var PING_BUSY_MS = 2000;
  var PING_JITTER_MS = 400;
  // The ESP answers nothing while it is waiting on WaspRadius (up to ~8 s per
  // request, e.g. its plan refresh). Timeouts below that would show a healthy
  // machine as offline, or fail a start that would have worked.
  var SLOW_MS = 12000;

  function baseUrl() {
    var ip = C.trim(C.cfg.coinslot_ip || '');
    if (!ip) return '';
    if (!/^https?:\/\//i.test(ip)) ip = 'http://' + ip;
    return ip.replace(/\/+$/, '');
  }

  function encode(obj) {
    var parts = [];
    for (var k in obj) {
      if (obj.hasOwnProperty(k)) parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(obj[k]));
    }
    return parts.join('&');
  }

  /* cb(status, json) - status 0 = the machine did not answer. */
  function esp(method, path, form, timeout, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, baseUrl() + path, true);
    xhr.timeout = timeout;
    if (form) xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      var json = null;
      try {
        json = JSON.parse(xhr.responseText);
      } catch (e) {}
      cb(xhr.status, json || {});
    };
    xhr.send(form ? encode(form) : null);
  }

  function money(amount) {
    var symbol = C.currencySymbol();
    return (symbol ? symbol : '') + C.formatPrice(amount || 0);
  }

  /*
   * opts = {
   *   wrapId, buttonId: the button area and its button (hidden until configured)
   *   mode:    'new' (new voucher) or 'extend' (add time to opts.voucher)
   *   voucher: current voucher for 'extend'
   *   idleText: button text when the machine is ready
   *   onCode:  function (code) - what to do with the voucher
   * }
   */
  function setup(opts) {
    if (!baseUrl()) return;
    var wrap = C.byId(opts.wrapId);
    var button = C.byId(opts.buttonId);
    var modal = C.byId('coin-modal');
    if (!wrap || !button || !modal) return;
    C.show(wrap);

    var token = '';
    var pollTimer = null;
    var timerMax = 0;
    var finished = false;

    function setButton(enabled, text) {
      button.disabled = !enabled;
      button.textContent = text;
    }

    var pinging = false;
    var pingTimer = null;

    // One ping at a time, scheduled after the answer (the ESP's web server is
    // single-threaded). The jitter matters once a few phones are waiting for the
    // same machine: without it they all ask on the same tick and queue up behind
    // each other, and the answers arrive late exactly when they matter most.
    function schedulePing(ms) {
      if (pingTimer) clearTimeout(pingTimer);
      pingTimer = setTimeout(ping, ms + Math.floor(Math.random() * PING_JITTER_MS));
    }

    /* What to put on the button while someone else has the machine. */
    function busyText(j) {
      var left = j && j.seconds_left;
      // Only the coin wait has a deadline; a dispense takes as long as the
      // server takes, so do not invent a number there.
      if (j && j.busy_reason === 'waiting' && typeof left === 'number' && left > 0) {
        return 'In use - free in about ' + left + 's';
      }
      return 'Coin machine busy, please wait';
    }

    function ping() {
      // Cancel a scheduled ping before running one: ping() is also called
      // directly (on close), and a forgotten timer would start a second chain
      // that polls the machine twice as often for the rest of the page's life.
      if (pingTimer) clearTimeout(pingTimer);
      pingTimer = null;
      if (token || pinging) return; // a session is open, or a ping is still out
      pinging = true;
      esp('GET', '/api/ping', null, SLOW_MS, function (status, j) {
        pinging = false;
        if (token) return; // this customer started a session while we were asking
        var busy = status === 200 && j.busy;
        if (status !== 200) setButton(false, 'Coin machine offline');
        else if (busy) setButton(false, busyText(j));
        else if (!j.ready) setButton(false, 'Coin machine not ready');
        else setButton(true, opts.idleText);
        schedulePing(busy ? PING_BUSY_MS : PING_READY_MS);
      });
    }

    function el(id) {
      return C.byId(id);
    }

    function message(type, text) {
      var m = el('coin-msg');
      if (!text) {
        C.show(m, false);
        return;
      }
      m.className = 'alert text-sm mt-3 ' + (type === 'ok' ? 'alert-success' : 'alert-error');
      m.textContent = text;
    }

    function buttons(state) {
      // state: 'start' (password step), 'waiting', 'busy', 'close'
      C.show('coin-start', state === 'start');
      C.show('coin-done', state === 'waiting');
      C.show('coin-cancel', state === 'waiting' || state === 'start');
      C.show('coin-close', state === 'close');
    }

    function openModal() {
      finished = false;
      message();
      C.show('coin-code-wrap', false);
      C.show('coin-timer', false);
      C.show('coin-note', false);
      el('coin-amount').textContent = money(0);
      el('coin-title').textContent = opts.mode === 'extend' ? 'Add time with coins' : 'Insert coins';
      modal.classList.add('modal-open');

      // Add time to a voucher with a password: the ESP must send it to WaspRadius.
      var needsPassword = opts.mode === 'extend' && C.getCookie('haspass') === '1';
      C.show('coin-pass-wrap', needsPassword);
      if (needsPassword) {
        el('coin-hint').textContent = 'Enter the password of your voucher, then insert coins.';
        buttons('start');
        el('coin-password').focus();
      } else {
        start();
      }
    }

    function closeModal() {
      stopPolling();
      token = '';
      modal.classList.remove('modal-open');
      ping();  // restarts the ping chain: it stops itself while a session is open
    }

    function stopPolling() {
      if (pollTimer) clearTimeout(pollTimer);
      pollTimer = null;
    }

    // One request at a time: the next poll is scheduled after the answer, so a
    // busy ESP (single-threaded web server) never gets a pile of queued polls.
    function schedulePoll() {
      stopPolling();
      if (token) pollTimer = setTimeout(poll, POLL_MS);
    }

    function start() {
      var form = { mode: opts.mode };
      if (opts.mode === 'extend') {
        form.voucher = opts.voucher;
        form.password = C.byId('coin-pass-wrap').className.indexOf('hidden') < 0 ? el('coin-password').value : opts.voucher;
      }
      C.show('coin-pass-wrap', false);
      el('coin-hint').textContent = 'Connecting to the coin machine...';
      buttons('busy');
      esp('POST', '/api/session/start', form, SLOW_MS, function (status, j) {
        // Someone else got there first: the button is only as fresh as the last
        // ping. Not a dead end - close, and let the button count the wait down.
        if (status === 409) {
          el('coin-hint').textContent = '';
          message('err', j.message || 'Someone is using the coin machine.');
          buttons('close');
          setButton(false, busyText(j));
          schedulePing(PING_BUSY_MS);
          return;
        }
        if (status !== 200 || !j.token) {
          el('coin-hint').textContent = '';
          message('err', status === 0 ? 'Cannot reach the coin machine.' : j.message || 'The coin machine is not available.');
          buttons('close');
          return;
        }
        token = j.token;
        timerMax = j.seconds_left || 0;
        render(j);
        schedulePoll();
      });
    }

    function poll() {
      if (!token) return;
      pollTimer = null;
      esp('GET', '/api/session?token=' + encodeURIComponent(token), null, SLOW_MS, function (status, j) {
        if (!token) return;
        if (status === 404) {
          message('err', 'The coin session ended.');
          buttons('close');
          token = '';
          return;
        }
        if (status === 200) render(j);
        schedulePoll();
      });
    }

    function render(j) {
      el('coin-amount').textContent = money(j.amount);
      var timer = el('coin-timer');

      if (j.state === 'waiting') {
        C.show(timer, true);
        // The window shrinks from "waiting for the first coin" to the shorter
        // "waiting for the next coin" once a coin drops; wait_seconds is that
        // window, so the bar restarts full instead of jumping backwards.
        if (j.wait_seconds) timerMax = j.wait_seconds;
        else if (j.seconds_left > timerMax) timerMax = j.seconds_left;
        timer.max = timerMax || 1;
        timer.value = j.seconds_left || 0;
        if (j.error === 'below_minimum') {
          message('err', 'Minimum is ' + money(j.min_amount) + '. Please insert more coins.');
        }
        el('coin-hint').textContent = j.amount > 0
          ? 'Insert more coins, or tap Done. (' + (j.seconds_left || 0) + 's)'
          : 'Insert coins now. (' + (j.seconds_left || 0) + 's)';
        // Coins an earlier customer left on the machine are spent by this one.
        // Say so, or the amount on screen looks like a miscount.
        var note = el('coin-note');
        if (note) {
          if (j.carried_credit > 0) {
            note.textContent = 'Includes ' + money(j.carried_credit) + ' left on this machine earlier.';
            C.show(note, true);
          } else {
            C.show(note, false);
          }
        }
        buttons('waiting');
        el('coin-done').disabled = !(j.amount > 0);
        return;
      }

      C.show(timer, false);
      C.show('coin-note', false);
      if (j.state === 'processing') {
        message();
        el('coin-hint').textContent = j.message || 'Getting your voucher...';
        buttons('busy');
        return;
      }

      stopPolling();
      if (finished) return;
      finished = true;

      if (j.state === 'done') {
        el('coin-code').textContent = j.code || '';
        C.show('coin-code-wrap', !!j.code);
        el('coin-hint').textContent = '';
        message('ok', opts.mode === 'extend' ? 'Time added!' : 'Paid! Connecting you now...');
        buttons('close');
        var code = j.code;
        token = '';
        setTimeout(function () {
          opts.onCode(code);
        }, 1500);
        return;
      }

      token = '';
      el('coin-hint').textContent = '';
      if (j.state === 'error') {
        if (j.code) {
          el('coin-code').textContent = j.code;
          C.show('coin-code-wrap');
        }
        if (j.error === 'rejected' && /password/i.test(j.message || '')) {
          message('err', 'Wrong voucher password. Your coins are saved on the machine; enter the password and try again.');
          C.show('coin-pass-wrap');
          el('coin-password').value = '';
          buttons('start');
          finished = false;
          return;
        }
        message('err', j.error === 'out_of_service'
          ? 'The coin machine is out of service. Your coins are saved on it.'
          : (j.message || 'Something went wrong. Your coins are saved on the machine.'));
      } else if (j.error === 'credit_saved') {
        message('ok', 'Your ' + money(j.amount || 0) + ' is saved on this machine and will be added to your next purchase.');
      } else {
        message('err', 'No coins were inserted.');
      }
      buttons('close');
    }

    button.onclick = openModal;
    el('coin-start').onclick = start;
    el('coin-close').onclick = closeModal;
    el('coin-done').onclick = function () {
      if (!token) return;
      el('coin-done').disabled = true;
      esp('POST', '/api/session/done', { token: token }, SLOW_MS, function (status, j) {
        if (status === 200) render(j);
      });
    };
    el('coin-cancel').onclick = function () {
      if (!token) {
        closeModal();
        return;
      }
      // Coins cannot be given back: with money inserted this still buys a plan.
      esp('POST', '/api/session/cancel', { token: token }, SLOW_MS, function (status, j) {
        if (status === 200 && (j.state === 'ended' && j.error === 'no_coins')) {
          closeModal();
        } else if (status === 200) {
          render(j);
        } else {
          closeModal();
        }
      });
    };

    setButton(false, 'Checking coin machine...');
    ping();
  }

  window.PortalCoinslot = { setup: setup, baseUrl: baseUrl };
})(window, document);

/* ---- targets/mikrotik/js/mikrotik.js ---- */
/*
 * MikroTik pages. The router fills in $-variables in the HTML (username, time
 * left, ...), so these functions read them from data-* attributes.
 * Same rule as the core: never write "$" followed by "(" in this file.
 */
(function (window, document) {
  'use strict';

  var C = window.PortalCore;

  /* ---------------- login.html ---------------- */

  function initLogin() {
    C.applyPortalName();
    C.renderRates();
    C.renderSlides();
    var form = document.forms.login;
    if (!form) return;
    C.initVoucherForm(form);

    if (window.PortalCoinslot) {
      window.PortalCoinslot.setup({
        wrapId: 'coin-wrap',
        buttonId: 'coin-open',
        mode: 'new',
        idleText: 'Insert Coin',
        // Log in with the new voucher exactly as if it had been typed: voucher
        // only (password = code), through doLogin() so CHAP still works.
        onCode: function (code) {
          form.username.value = code;
          var hasPass = C.byId('has-pass');
          if (hasPass && hasPass.checked) {
            hasPass.checked = false;
            if (hasPass.onchange) hasPass.onchange();
          }
          if (typeof window.doLogin !== 'function' || window.doLogin() !== false) form.submit();
        },
      });
    }
  }

  /* Called from the login form. `chap` = { id, challenge } when the router uses CHAP. */
  function submitLogin(chap) {
    var form = document.forms.login;
    var v = C.readVoucherForm(form);
    if (!v) return false;

    C.setBusy('login-btn');

    if (chap && typeof hexMD5 === 'function') {
      var sendin = document.forms.sendin;
      sendin.username.value = v.user;
      sendin.password.value = hexMD5(chap.id + v.pass + chap.challenge);
      sendin.submit();
      return false;
    }
    form.username.value = v.user;
    form.password.value = v.pass;
    return true;
  }

  /* ---------------- status.html ---------------- */

  function initStatus() {
    C.applyPortalName();
    var b = document.body;
    var info = {
      username: b.getAttribute('data-username') || '',
      mac: b.getAttribute('data-mac') || '',
      ip: b.getAttribute('data-ip') || '',
      loginBy: b.getAttribute('data-login-by') || '',
    };

    var left = C.toSeconds(b.getAttribute('data-time-left-secs'), b.getAttribute('data-time-left'));
    var used = C.toSeconds(b.getAttribute('data-uptime-secs'), b.getAttribute('data-uptime'));
    var syncedAt = new Date().getTime();

    var dataLeft = b.getAttribute('data-bytes-left');
    if (dataLeft) C.setText('data-left', C.formatBytes(dataLeft));

    function tick() {
      var elapsed = Math.floor((new Date().getTime() - syncedAt) / 1000);
      if (!isNaN(used)) C.setText('uptime', C.formatDuration(used + elapsed));
      if (!isNaN(left)) {
        var remaining = left - elapsed;
        C.setText('time-left', C.formatDuration(remaining));
        if (remaining <= 0) {
          // Session is over: router will send the user back to the login page.
          setTimeout(function () {
            window.location.reload();
          }, 3000);
          clearInterval(tickTimer);
        }
      }
    }
    tick();
    var tickTimer = setInterval(tick, 1000);

    // Re-sync with the router every 30s instead of polling every second.
    function sync() {
      C.request('GET', '/time.txt?_=' + new Date().getTime(), null, function (ok, json) {
        if (!ok) return;
        if (!json) {
          window.location.reload(); // not JSON = not logged in anymore
          return;
        }
        var l = C.toSeconds(json.timeleftsecs, json.timeleft);
        var u = C.toSeconds(json.uptimesecs, json.timeused);
        syncedAt = new Date().getTime();
        if (!isNaN(l)) left = l;
        if (!isNaN(u)) used = u;
        if (json.dataleft) C.setText('data-left', C.formatBytes(json.dataleft));
        tick();
      });
    }
    setInterval(sync, 30000);

    C.setupExtend(info, sync);

    // Add time with coins: same voucher; the router gets the new time through
    // WaspRadius (CoA), so reload to show the router's updated countdown.
    if (window.PortalCoinslot && info.loginBy !== 'mac' && info.loginBy !== 'trial' && info.username) {
      window.PortalCoinslot.setup({
        wrapId: 'coin-wrap',
        buttonId: 'coin-open',
        mode: 'extend',
        voucher: info.username,
        idleText: 'Add time with coins',
        onCode: function () {
          window.location.reload();
        },
      });
    }

    // The router knows the time left but not the validity window. A MAC or
    // trial login has no voucher code to look up, so skip those.
    if (info.loginBy !== 'mac' && info.loginBy !== 'trial') {
      C.fetchVoucherInfo(info.username, function (ok, data) {
        if (ok && data) C.showValidUntil(data.expiration);
      });
    }
  }

  /* ---------------- logout.html ---------------- */

  function initLogout() {
    C.applyPortalName();
    var nodes = document.querySelectorAll('[data-bytes]');
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].textContent = C.formatBytes(nodes[i].getAttribute('data-bytes'));
    }
    var form = document.forms.resume;
    if (form) {
      form.onsubmit = function () {
        var user = document.body.getAttribute('data-username');
        if (user) C.setCookie('vouch', user, 1); // pre-fills the voucher on the login page
        return true;
      };
    }
  }

  window.Portal = {
    cfg: C.cfg,
    initLogin: initLogin,
    submitLogin: submitLogin,
    initStatus: initStatus,
    initLogout: initLogout,
    applyPortalName: C.applyPortalName,
  };
})(window, document);
